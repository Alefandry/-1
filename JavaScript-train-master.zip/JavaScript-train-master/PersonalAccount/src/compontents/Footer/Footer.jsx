import React from 'react'

export const Footer = () => {
  return (
    <div style={{ border: '1px solid #333', height: '140px' }}>Footer</div>
  )
}
