import { useEffect, useState } from "react"

export const useCustomHook = (params1 = '', params2 = '', params3 = '') => {

  // const [value, setValue] = useState('any value from custom hook')


  // useEffect(() => {
  //   if (params1) {
  //     setValue(params1)
  //   }
  // }, [params1, params2, params3])

  // const anyMethod = () => {

  // }

  // return value
}