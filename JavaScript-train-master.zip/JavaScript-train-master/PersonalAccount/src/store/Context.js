import { createContext } from "react";

export const MyStore = createContext()